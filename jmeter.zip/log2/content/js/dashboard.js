/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 6;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 98.10760259654528, "KoPercent": 1.8923974034547255};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9842172875757019, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "Go_to_link"], "isController": true}, {"data": [1.0, 500, 1500, "go_to_guestbook"], "isController": false}, {"data": [0.9522752497225305, 500, 1500, "appear_comment"], "isController": false}, {"data": [1.0, 500, 1500, "go_to_link_2"], "isController": false}, {"data": [1.0, 500, 1500, "Guestbook"], "isController": true}, {"data": [0.9522752497225305, 500, 1500, "send_comment"], "isController": false}, {"data": [1.0, 500, 1500, "Go_to_link_2"], "isController": true}, {"data": [1.0, 500, 1500, "go_to_clients"], "isController": false}, {"data": [1.0, 500, 1500, "Go_to_clients"], "isController": true}, {"data": [1.0, 500, 1500, "guestbook"], "isController": false}, {"data": [1.0, 500, 1500, "JDBC Request"], "isController": false}, {"data": [1.0, 500, 1500, "go_to_link"], "isController": false}, {"data": [1.0, 500, 1500, "Go_to_guestbook"], "isController": true}, {"data": [1.0, 500, 1500, "Go_to_guestbook_2"], "isController": true}, {"data": [0.9522752497225305, 500, 1500, "Send_comment"], "isController": true}, {"data": [1.0, 500, 1500, "go_to_guestbook_2"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 9089, 172, 1.8923974034547255, 4.4944438332049454, 1, 363, 6.0, 7.0, 23.0, 30.264686980757, 230.3875304834142, 11.900049312476483], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "90th pct", "95th pct", "99th pct", "Transactions\/s", "Received", "Sent"], "items": [{"data": ["Go_to_link", 1803, 0, 0.0, 5.54686633388797, 0, 131, 6.0, 7.0, 14.960000000000036, 6.000698916679148, 132.75625254813374, 1.962030467358927], "isController": true}, {"data": ["go_to_guestbook", 1802, 0, 0.0, 4.967258601553846, 2, 36, 5.0, 6.0, 11.0, 6.002444947053906, 24.103567990513337, 2.309534481581288], "isController": false}, {"data": ["appear_comment", 1802, 86, 4.772475027746948, 2.5110987791342945, 1, 44, 4.0, 5.0, 19.970000000000027, 6.0029448408653305, 33.83759816309721, 1.7469507447049497], "isController": false}, {"data": ["go_to_link_2", 16, 0, 0.0, 10.124999999999998, 5, 62, 25.600000000000037, 62.0, 62.0, 0.05695612242718516, 1.2607660420478572, 0.018633106458112333], "isController": false}, {"data": ["Guestbook", 16, 0, 0.0, 33.1875, 3, 380, 138.50000000000023, 380.0, 380.0, 0.056970724169117595, 0.4831558320663282, 0.01657937090077836], "isController": true}, {"data": ["send_comment", 1802, 86, 4.772475027746948, 4.214206437291906, 1, 64, 10.0, 19.0, 32.97000000000003, 6.002684885692491, 1.8537865975985928, 3.60406763513536], "isController": false}, {"data": ["Go_to_link_2", 17, 0, 0.0, 9.52941176470588, 0, 62, 20.399999999999963, 62.0, 62.0, 0.060480356336028857, 1.260025953188204, 0.018622168540964767], "isController": true}, {"data": ["go_to_clients", 1802, 0, 0.0, 4.98057713651498, 2, 40, 5.0, 6.0, 10.970000000000027, 6.002125058705579, 35.960059102154375, 2.227351096004024], "isController": false}, {"data": ["Go_to_clients", 1802, 0, 0.0, 4.98057713651498, 2, 40, 5.0, 6.0, 10.970000000000027, 6.002125058705579, 35.960059102154375, 2.227351096004024], "isController": true}, {"data": ["guestbook", 16, 0, 0.0, 6.000000000000001, 2, 17, 15.600000000000001, 17.0, 17.0, 0.056971129879933344, 0.4824638244452436, 0.016579488968964978], "isController": false}, {"data": ["JDBC Request", 31, 0, 0.0, 14.677419354838712, 1, 363, 9.8, 164.99999999999955, 363.0, 0.11038745998454576, 0.0012483964886105068, 0.0], "isController": false}, {"data": ["go_to_link", 1802, 0, 0.0, 5.549944506104334, 3, 131, 6.0, 7.0, 14.970000000000027, 6.0008458461958565, 132.83317655832175, 1.9631673422613398], "isController": false}, {"data": ["Go_to_guestbook", 1802, 0, 0.0, 4.967258601553846, 2, 36, 5.0, 6.0, 11.0, 6.002384965391354, 24.103327126649656, 2.3095114026994077], "isController": true}, {"data": ["Go_to_guestbook_2", 16, 0, 0.0, 5.687500000000001, 4, 11, 8.900000000000002, 11.0, 11.0, 0.05696991276482108, 0.22876980594623464, 0.02125244792593911], "isController": true}, {"data": ["Send_comment", 1802, 86, 4.772475027746948, 6.725305216426198, 2, 67, 15.0, 24.0, 39.940000000000055, 6.002624899234515, 35.68956277772966, 5.350889255401363], "isController": true}, {"data": ["go_to_guestbook_2", 16, 0, 0.0, 5.687500000000001, 4, 11, 8.900000000000002, 11.0, 11.0, 0.05696991276482108, 0.22876980594623464, 0.02125244792593911], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Percentile 1
            case 8:
            // Percentile 2
            case 9:
            // Percentile 3
            case 10:
            // Throughput
            case 11:
            // Kbytes/s
            case 12:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Test failed: text expected to contain \\\/&lt;b&gt;\\u0426\\u0435\\u043D\\u0442\\u0440\\u0430\\u043B\\u044C\\u043D\\u044B\\u0439 \\u0431\\u0430\\u043D\\u043A \\u0420\\u043E\\u0441\\u0441\\u0438\\u0439\\u0441\\u043A\\u043E\\u0439 \\u0424\\u0435\\u0434\\u0435\\u0440\\u0430\\u0446\\u0438\\u0438&lt;\\\/b&gt;: \'\\u0421\\u043F\\u0430\\u0441\\u0438\\u0431\\u043E!!!!\'&lt;br&gt;\\\/", 24, 13.953488372093023, 0.2640554516448454], "isController": false}, {"data": ["Test failed: text expected to contain \\\/&lt;b&gt;\\u0426\\u0435\\u043D\\u0442\\u0440\\u0430\\u043B\\u044C\\u043D\\u044B\\u0439 \\u0431\\u0430\\u043D\\u043A \\u0420\\u043E\\u0441\\u0441\\u0438\\u0439\\u0441\\u043A\\u043E\\u0439 \\u0424\\u0435\\u0434\\u0435\\u0440\\u0430\\u0446\\u0438\\u0438&lt;\\\/b&gt;: \'\\u0420\\u0435\\u0431\\u044F\\u0442\\u0430, \\u0432\\u044B \\u043B\\u0443\\u0447\\u0448\\u0438\\u0435!\'&lt;br&gt;\\\/", 23, 13.372093023255815, 0.2530531411596435], "isController": false}, {"data": ["500", 86, 50.0, 0.9461987017273628], "isController": false}, {"data": ["Test failed: text expected to contain \\\/&lt;b&gt;\\u0426\\u0435\\u043D\\u0442\\u0440\\u0430\\u043B\\u044C\\u043D\\u044B\\u0439 \\u0431\\u0430\\u043D\\u043A \\u0420\\u043E\\u0441\\u0441\\u0438\\u0439\\u0441\\u043A\\u043E\\u0439 \\u0424\\u0435\\u0434\\u0435\\u0440\\u0430\\u0446\\u0438\\u0438&lt;\\\/b&gt;: \'\\u0412\\u044B \\u0435\\u0449\\u0435 \\u043E\\u0442\\u0431\\u0435\\u043B\\u0438\\u0432\\u0430\\u0435\\u0442\\u0435? \\u0442\\u043E\\u0433\\u0434\\u0430 \\u043C\\u044B \\u0438\\u0434\\u0435\\u043C \\u043A \\u0432\\u0430\\u043C!\'&lt;br&gt;\\\/", 19, 11.046511627906977, 0.20904389921883595], "isController": false}, {"data": ["Test failed: text expected to contain \\\/&lt;b&gt;\\u0426\\u0435\\u043D\\u0442\\u0440\\u0430\\u043B\\u044C\\u043D\\u044B\\u0439 \\u0431\\u0430\\u043D\\u043A \\u0420\\u043E\\u0441\\u0441\\u0438\\u0439\\u0441\\u043A\\u043E\\u0439 \\u0424\\u0435\\u0434\\u0435\\u0440\\u0430\\u0446\\u0438\\u0438&lt;\\\/b&gt;: \'\\u0422\\u0435\\u0441\\u0442\\u0438\\u0440\\u043E\\u0432\\u0430\\u043D\\u0438\\u0435, \\u0442\\u043E \\u0442\\u043E\\u043B\\u044C\\u043A\\u043E \\u0410\\u043F\\u043B\\u0430\\u043D\\u0430\'&lt;br&gt;\\\/", 20, 11.627906976744185, 0.22004620970403785], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 9089, 172, "500", 86, "Test failed: text expected to contain \\\/&lt;b&gt;\\u0426\\u0435\\u043D\\u0442\\u0440\\u0430\\u043B\\u044C\\u043D\\u044B\\u0439 \\u0431\\u0430\\u043D\\u043A \\u0420\\u043E\\u0441\\u0441\\u0438\\u0439\\u0441\\u043A\\u043E\\u0439 \\u0424\\u0435\\u0434\\u0435\\u0440\\u0430\\u0446\\u0438\\u0438&lt;\\\/b&gt;: \'\\u0421\\u043F\\u0430\\u0441\\u0438\\u0431\\u043E!!!!\'&lt;br&gt;\\\/", 24, "Test failed: text expected to contain \\\/&lt;b&gt;\\u0426\\u0435\\u043D\\u0442\\u0440\\u0430\\u043B\\u044C\\u043D\\u044B\\u0439 \\u0431\\u0430\\u043D\\u043A \\u0420\\u043E\\u0441\\u0441\\u0438\\u0439\\u0441\\u043A\\u043E\\u0439 \\u0424\\u0435\\u0434\\u0435\\u0440\\u0430\\u0446\\u0438\\u0438&lt;\\\/b&gt;: \'\\u0420\\u0435\\u0431\\u044F\\u0442\\u0430, \\u0432\\u044B \\u043B\\u0443\\u0447\\u0448\\u0438\\u0435!\'&lt;br&gt;\\\/", 23, "Test failed: text expected to contain \\\/&lt;b&gt;\\u0426\\u0435\\u043D\\u0442\\u0440\\u0430\\u043B\\u044C\\u043D\\u044B\\u0439 \\u0431\\u0430\\u043D\\u043A \\u0420\\u043E\\u0441\\u0441\\u0438\\u0439\\u0441\\u043A\\u043E\\u0439 \\u0424\\u0435\\u0434\\u0435\\u0440\\u0430\\u0446\\u0438\\u0438&lt;\\\/b&gt;: \'\\u0422\\u0435\\u0441\\u0442\\u0438\\u0440\\u043E\\u0432\\u0430\\u043D\\u0438\\u0435, \\u0442\\u043E \\u0442\\u043E\\u043B\\u044C\\u043A\\u043E \\u0410\\u043F\\u043B\\u0430\\u043D\\u0430\'&lt;br&gt;\\\/", 20, "Test failed: text expected to contain \\\/&lt;b&gt;\\u0426\\u0435\\u043D\\u0442\\u0440\\u0430\\u043B\\u044C\\u043D\\u044B\\u0439 \\u0431\\u0430\\u043D\\u043A \\u0420\\u043E\\u0441\\u0441\\u0438\\u0439\\u0441\\u043A\\u043E\\u0439 \\u0424\\u0435\\u0434\\u0435\\u0440\\u0430\\u0446\\u0438\\u0438&lt;\\\/b&gt;: \'\\u0412\\u044B \\u0435\\u0449\\u0435 \\u043E\\u0442\\u0431\\u0435\\u043B\\u0438\\u0432\\u0430\\u0435\\u0442\\u0435? \\u0442\\u043E\\u0433\\u0434\\u0430 \\u043C\\u044B \\u0438\\u0434\\u0435\\u043C \\u043A \\u0432\\u0430\\u043C!\'&lt;br&gt;\\\/", 19], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["appear_comment", 1802, 86, "Test failed: text expected to contain \\\/&lt;b&gt;\\u0426\\u0435\\u043D\\u0442\\u0440\\u0430\\u043B\\u044C\\u043D\\u044B\\u0439 \\u0431\\u0430\\u043D\\u043A \\u0420\\u043E\\u0441\\u0441\\u0438\\u0439\\u0441\\u043A\\u043E\\u0439 \\u0424\\u0435\\u0434\\u0435\\u0440\\u0430\\u0446\\u0438\\u0438&lt;\\\/b&gt;: \'\\u0421\\u043F\\u0430\\u0441\\u0438\\u0431\\u043E!!!!\'&lt;br&gt;\\\/", 24, "Test failed: text expected to contain \\\/&lt;b&gt;\\u0426\\u0435\\u043D\\u0442\\u0440\\u0430\\u043B\\u044C\\u043D\\u044B\\u0439 \\u0431\\u0430\\u043D\\u043A \\u0420\\u043E\\u0441\\u0441\\u0438\\u0439\\u0441\\u043A\\u043E\\u0439 \\u0424\\u0435\\u0434\\u0435\\u0440\\u0430\\u0446\\u0438\\u0438&lt;\\\/b&gt;: \'\\u0420\\u0435\\u0431\\u044F\\u0442\\u0430, \\u0432\\u044B \\u043B\\u0443\\u0447\\u0448\\u0438\\u0435!\'&lt;br&gt;\\\/", 23, "Test failed: text expected to contain \\\/&lt;b&gt;\\u0426\\u0435\\u043D\\u0442\\u0440\\u0430\\u043B\\u044C\\u043D\\u044B\\u0439 \\u0431\\u0430\\u043D\\u043A \\u0420\\u043E\\u0441\\u0441\\u0438\\u0439\\u0441\\u043A\\u043E\\u0439 \\u0424\\u0435\\u0434\\u0435\\u0440\\u0430\\u0446\\u0438\\u0438&lt;\\\/b&gt;: \'\\u0422\\u0435\\u0441\\u0442\\u0438\\u0440\\u043E\\u0432\\u0430\\u043D\\u0438\\u0435, \\u0442\\u043E \\u0442\\u043E\\u043B\\u044C\\u043A\\u043E \\u0410\\u043F\\u043B\\u0430\\u043D\\u0430\'&lt;br&gt;\\\/", 20, "Test failed: text expected to contain \\\/&lt;b&gt;\\u0426\\u0435\\u043D\\u0442\\u0440\\u0430\\u043B\\u044C\\u043D\\u044B\\u0439 \\u0431\\u0430\\u043D\\u043A \\u0420\\u043E\\u0441\\u0441\\u0438\\u0439\\u0441\\u043A\\u043E\\u0439 \\u0424\\u0435\\u0434\\u0435\\u0440\\u0430\\u0446\\u0438\\u0438&lt;\\\/b&gt;: \'\\u0412\\u044B \\u0435\\u0449\\u0435 \\u043E\\u0442\\u0431\\u0435\\u043B\\u0438\\u0432\\u0430\\u0435\\u0442\\u0435? \\u0442\\u043E\\u0433\\u0434\\u0430 \\u043C\\u044B \\u0438\\u0434\\u0435\\u043C \\u043A \\u0432\\u0430\\u043C!\'&lt;br&gt;\\\/", 19, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["send_comment", 1802, 86, "500", 86, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
