/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 6;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.22865013774104, "KoPercent": 0.7713498622589532};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9907773386034255, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "Go_to_link"], "isController": true}, {"data": [1.0, 500, 1500, "go_to_guestbook"], "isController": false}, {"data": [1.0, 500, 1500, "appear_comment"], "isController": false}, {"data": [1.0, 500, 1500, "Guestbook"], "isController": true}, {"data": [0.9536423841059603, 500, 1500, "send_comment"], "isController": false}, {"data": [1.0, 500, 1500, "go_to_clients"], "isController": false}, {"data": [1.0, 500, 1500, "Go_to_clients"], "isController": true}, {"data": [1.0, 500, 1500, "guestbook"], "isController": false}, {"data": [1.0, 500, 1500, "JDBC Request"], "isController": false}, {"data": [1.0, 500, 1500, "go_to_link"], "isController": false}, {"data": [1.0, 500, 1500, "Go_to_guestbook"], "isController": true}, {"data": [0.9536423841059603, 500, 1500, "Send_comment"], "isController": true}, {"data": [1.0, 500, 1500, "OK"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 1815, 14, 0.7713498622589532, 8.043526170798897, 0, 315, 14.0, 15.0, 19.0, 6.047359319763703, 39.95525794882069, 1.999276722081358], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "90th pct", "95th pct", "99th pct", "Transactions\/s", "Received", "Sent"], "items": [{"data": ["Go_to_link", 307, 0, 0.0, 12.117263843648217, 3, 64, 16.0, 16.0, 19.0, 1.0227708093881698, 22.63979095351723, 0.3345978722119501], "isController": true}, {"data": ["go_to_guestbook", 305, 0, 0.0, 10.688524590163937, 4, 18, 14.400000000000034, 15.0, 17.0, 1.0179832583474626, 4.087839021801529, 0.3915676253788232], "isController": false}, {"data": ["appear_comment", 302, 0, 0.0, 5.3841059602649075, 2, 55, 7.699999999999989, 8.0, 11.0, 1.0078458463068456, 4.014348480430437, 0.29329888886664063], "isController": false}, {"data": ["Guestbook", 3, 0, 0.0, 79.0, 23, 188, 188.0, 188.0, 188.0, 0.01663708961845608, 0.060298618428349604, 0.004841653033496008], "isController": true}, {"data": ["send_comment", 302, 14, 4.635761589403973, 8.172185430463575, 2, 315, 9.0, 15.849999999999966, 94.85999999999888, 1.0076508056201559, 0.30972632750486306, 0.6054643837564688], "isController": false}, {"data": ["go_to_clients", 302, 0, 0.0, 10.735099337748336, 4, 27, 14.0, 15.0, 17.96999999999997, 1.0083135788454476, 6.041019342008615, 0.3741788671496778], "isController": false}, {"data": ["Go_to_clients", 303, 0, 0.0, 10.69966996699669, 0, 27, 14.0, 15.0, 17.95999999999998, 1.0097980403919218, 6.0299463544791045, 0.37349300973138705], "isController": true}, {"data": ["guestbook", 3, 0, 0.0, 8.666666666666666, 4, 13, 13.0, 13.0, 13.0, 0.016638658258598026, 0.06010931945114613, 0.0048421095322873165], "isController": false}, {"data": ["JDBC Request", 6, 0, 0.0, 35.833333333333336, 1, 179, 179.0, 179.0, 179.0, 0.029952375722601066, 3.266290972353957E-4, 0.0], "isController": false}, {"data": ["go_to_link", 307, 0, 0.0, 12.117263843648217, 3, 64, 16.0, 16.0, 19.0, 1.0228866728195356, 22.642355676562904, 0.3346357767524848], "isController": false}, {"data": ["Go_to_guestbook", 306, 0, 0.0, 10.653594771241831, 0, 18, 14.300000000000011, 15.0, 17.0, 1.0216346153846154, 4.089094634748932, 0.39168789855435365], "isController": true}, {"data": ["Send_comment", 302, 14, 4.635761589403973, 13.559602649006623, 4, 317, 16.0, 23.0, 97.85999999999888, 1.007966944024458, 4.32465432491247, 0.8989884711694753], "isController": true}, {"data": ["OK", 288, 0, 0.0, 0.14583333333333337, 0, 1, 1.0, 1.0, 1.0, 0.9627277285642654, 2.8594396362610732, 0.0], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Percentile 1
            case 8:
            // Percentile 2
            case 9:
            // Percentile 3
            case 10:
            // Throughput
            case 11:
            // Kbytes/s
            case 12:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["500", 14, 100.0, 0.7713498622589532], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 1815, 14, "500", 14, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["send_comment", 302, 14, "500", 14, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
